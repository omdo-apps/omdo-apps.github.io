# Credits - Orbit Dodge press kit (OMDO)

- **Game and press images:** Orbit Dodge by OMDO. Free to use in coverage of the game.
- **Font in the store graphics:** Rubik (Bold for the captions, Regular for the feature-graphic tagline), version 1.100, Copyright 2015 Hubert & Fischer. Licensed under the SIL Open Font License, Version 1.1 (https://openfontlicense.org). It is the same font the game's UI uses.
- **Game text inside the screenshots:** drawn by the game itself with its bundled Rubik (OFL 1.1).
- **Art:** the Orbit Dodge HD art set and the Orbit Dodge logo (original, made by the team), and the game's Play icon.
- **Screenshots:** real captures of the Orbit Dodge build (HD art + UI v2) on the Android emulator, 2026-11-23. Every number shown was drawn by the game during a real run.
